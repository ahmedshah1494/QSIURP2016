#!/bin/bash

#this uses the qsub to submit jobs
#Remember - For Each Fold - the GMM is trained on rest of folds. So GMM stored in fold1  is trained on all folds except fold1.

nComp=128
trds=ESC-10
fldsz=5
qsz=hplong
gmstr=sklearn
WorF=Folds # Full/Folds for supdata -- for weakdata it is always Full

listend=.mfcc.list

suplist=../supdata/lists/$trds
weklist=../weakdata/lists/$trds

gmbsdr=../GMMs/$trds/$WorF


errd="errflsGMM"
log="logflsGMM"

mkdir -p $errd 
mkdir -p $log
mkdir -p temp

fold=`seq 1 $fldsz`
#declare -a fold=(3)



if [ "$WorF" == "Full" ];then
    echo " Not set "
elif [ "$WorF" == "Folds" ];then

    for f in $fold
    #for f in "${fold[@]}" 
    do 	
	supfldlist=$suplist/$WorF/fold$f/fold$f"_"train$listend
	tmpsupfl=temp/$trds.fold$f.gtrain.$nComp$listend.sup
	sed "s|../|../supdata/|" $supfldlist > $tmpsupfl
	wekfldlist=$weklist/Full/Full$listend
	tmpwekfl=temp/$trds.fold$f.Full.gtrain.$nComp$listend.weaksup
	sed "s|../|../weakdata/|" $wekfldlist > $tmpwekfl
	combfl=temp/$trds.fold$f.gtrain.Full.$nComp$listend.merge
	
	evJbnm=$trds"."$f"."$nComp
	errPt=$errd/"err."$evJbnm
	outPt=$errd/"out."$evJbnm
	logfl=$log/"log."$evJbnm

	gmmfolder=$gmbsdr/fold$f/$gmstr

	#python featscripts/GMMSklearnSWSL.py sup.mfcc.list weak.mfcc.list merge.mfcc.list 512 ../GMMs/ESC-10/
    	echo $gmmfolder
	qsub -q $qsz -N $evJbnm -e $errPt -o $outPt -v slist=$tmpsupfl,wlist=$tmpwekfl,mglist=$combfl,nCmp=$nComp,gmfold=$gmmfolder,logf=$logfl GMMTrainWkhs.sh
    #echo "$evJbnm submitted"
	
    done

fi
